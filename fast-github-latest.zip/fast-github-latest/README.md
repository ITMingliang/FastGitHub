# FastGithub
github加速神器

### 项目介绍
* 由于gitee的多次不公开原因误报readme，项目不再在gitee上同步更新；
* 请到[发行版](https://gitee.com/jiulang/fast-github/releases)页面下载最后一个版本，连接到github之后再从github升级。